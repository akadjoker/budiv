#pragma once

 
#include "Utils.hpp"
#include "Lexer.hpp"

class Parser;
class VM;

enum class Precedence {
    NONE = 0,
    ASSIGNMENT = 1,    // =, +=, -=
    OR = 2,           // OR
    AND = 3,          // AND
    BIT_OR = 4,       // |
    BIT_XOR = 5,      // ^^
    BIT_AND = 6,      // &
    EQUALITY = 7,     // ==, !=
    COMPARISON = 8,   // <, >, <=, >=
    SHIFT = 9,        // <<, >>
    TERM = 10,        // +, -
    FACTOR = 11,      // *, /, %
    POWER = 12,       // ^
    UNARY = 13,       // !, -, NOT, ~
    CALL = 14,        // . ()
    PRIMARY = 15,
    NOT = 16
};





typedef void (Parser::*PrefixFn)();
typedef void (Parser::*InfixFn)();

// ParseRule class
class ParseRule {
public:
    PrefixFn prefix;
    InfixFn infix;
    Precedence precedence;
    
    ParseRule() : prefix(nullptr), infix(nullptr), precedence(Precedence::NONE) {}
    
    ParseRule(PrefixFn p, InfixFn i, Precedence prec) 
        : prefix(p), infix(i), precedence(prec) {}
};


class Parser 
{
private:
    Lexer* lexer;
    Token current;
    Token previous;
    bool had_error;
    bool panic_mode;
    int index;
    UnorderedMap<TokenType, ParseRule> rules;
    VM* vm;
    Vector<Token> tokens;
 
    //ParseRule rules[256];
    void initRules() ;
    void synchronize();
    void errorAtCurrent(const String& message);
    void error(const String& message);
    void errorAt(const Token& token, const String& message);
    void consume(TokenType type, const String& message);
    bool match(TokenType type);
    void advance();


        void expression();
        void equality();
        void comparison();
        void term();
        void factor();
        void unary();
        void power();
        void call();
        void primary();

public:
 
    Parser(VM* vm);

    bool compile();
};