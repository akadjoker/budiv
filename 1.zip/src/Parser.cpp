#include "Parser.hpp"
#include "VM.hpp"
#include "Token.hpp"
#include "Lexer.hpp"

void Parser::initRules()
 {
    //  // Literals
    //     rules[TokenType::NUMBER] = ParseRule(&Parser::number, nullptr, Precedence::NONE);
    //     rules[TokenType::STRING] = ParseRule(&Parser::string, nullptr, Precedence::NONE);
    //     rules[TokenType::CHAR] = ParseRule(&Parser::char_, nullptr, Precedence::NONE);
    //     rules[TokenType::IDENTIFIER] = ParseRule(&Parser::variable, nullptr, Precedence::NONE);
    //     rules[TokenType::TRUE] = ParseRule(&Parser::literal, nullptr, Precedence::NONE);
    //     rules[TokenType::FALSE] = ParseRule(&Parser::literal, nullptr, Precedence::NONE);
    //     rules[TokenType::NIL] = ParseRule(&Parser::literal, nullptr, Precedence::NONE);
    //     rules[TokenType::TIME] = ParseRule(&Parser::time_expression, nullptr, Precedence::NONE);
        
    //     // Operators
    //     rules[TokenType::PLUS] = ParseRule(nullptr, &Parser::binary, Precedence::TERM);
    //     rules[TokenType::MINUS] = ParseRule(&Parser::unary, &Parser::binary, Precedence::TERM);
    //     rules[TokenType::MULTIPLY] = ParseRule(nullptr, &Parser::binary, Precedence::FACTOR);
    //     rules[TokenType::DIVIDE] = ParseRule(nullptr, &Parser::binary, Precedence::FACTOR);
    //     rules[TokenType::MODULO] = ParseRule(nullptr, &Parser::binary, Precedence::FACTOR);
    //     rules[TokenType::POWER] = ParseRule(nullptr, &Parser::binary, Precedence::POWER);
        
    //     // Comparison
    //     rules[TokenType::EQUAL] = ParseRule(nullptr, &Parser::binary, Precedence::EQUALITY);
    //     rules[TokenType::NOT_EQUAL] = ParseRule(nullptr, &Parser::binary, Precedence::EQUALITY);
    //     rules[TokenType::LESS] = ParseRule(nullptr, &Parser::binary, Precedence::COMPARISON);
    //     rules[TokenType::GREATER] = ParseRule(nullptr, &Parser::binary, Precedence::COMPARISON);
    //     rules[TokenType::LESS_EQUAL] = ParseRule(nullptr, &Parser::binary, Precedence::COMPARISON);
    //     rules[TokenType::GREATER_EQUAL] = ParseRule(nullptr, &Parser::binary, Precedence::COMPARISON);
        
    //     // Logical
    //     rules[TokenType::LOGICAL_AND] = ParseRule(nullptr, &Parser::binary, Precedence::AND);
    //     rules[TokenType::LOGICAL_OR] = ParseRule(nullptr, &Parser::binary, Precedence::OR);
    //     rules[TokenType::LOGICAL_NOT] = ParseRule(&Parser::unary, nullptr, Precedence::UNARY);
        
    //     // Grouping
    //     rules[TokenType::LEFT_PAREN] = ParseRule(&Parser::grouping, nullptr, Precedence::NONE);
 }

 void Parser::errorAtCurrent(const String& message) 
 {
    errorAt(current, message);
 }

 void Parser::error(const String& message) 
 {
    errorAt(previous, message);
 }

 void Parser::errorAt(const Token& token, const String& message) 
 {
     if (panic_mode) return;
     panic_mode = true;
     if (token.type == TokenType::END_OF_FILE) 
     {
         ERROR("[line %d] Error (%s) at end", token.line, message.c_str());
     } 
     else 
     {
         ERROR("[line %d] Error %s at '%s' (%s) ", token.line, token.lexeme.c_str(),message.c_str());
     }

    had_error = true;
 }

 void Parser::consume(TokenType type, const String& message) 
 {
    if (current.type == type) 
    {
        advance();
        return;
    }
    errorAtCurrent(message);
 }

 Parser::Parser(VM *vm) 
 {
    initRules();
    had_error = false;
    panic_mode = false;
 }

 bool Parser::compile() { return !had_error; }


void Parser::advance() 
{
    previous = current; 
    for (;;) 
    {
        current = lexer->scanToken();
        if (current.type != TokenType::ERROR) break;
        errorAtCurrent(current.lexeme);
    }


}