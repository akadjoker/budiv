#include "VM.hpp"
#include "Utils.hpp"


u32 Process::nextPID = 1;


Process::Process()
{
    function = new ObjFunction("__main__");
    size_t len = strlen("Process");
    strncpy(name, "Process", len);
    name[len] = '\0';
    ip = function->chunk.code;
    id = nextPID++;
    priority = 0;
    status = STATUS_RUNNING;
    frame_percent = 0;
    saved_status = status;
    saved_priority = 0;
    last_priority = 0;
    next = nullptr;
    prev = nullptr;
    frameCount = 0;
    for (int i = 0; i < STACK_MAX; i++)
    {
        stack[i] = NIL();
    }
    stackTop = &stack[0];
    //call(function, 0);
}

Process::~Process()
{
    INFO("deleting process: %s", name);
    if (function != nullptr) delete function;
}

    void Process::resetStack()
    {
        stackTop = stack;
        frameCount = 0;
    }

    void Process::push(Value value)
    {
        *stackTop = value;
        stackTop++;
    }

    Value Process::pop()
    {
        stackTop--;
        return *stackTop;
    }

    Value Process::peek(int distance) { return stackTop[-1 - distance]; }

bool Process::is_alive() const
{
    return status != STATUS_DEAD && status != STATUS_KILLED;
}

bool Process::should_execute() const
{
    return status == STATUS_RUNNING && frame_percent < 100;
}

 bool Process::call(ObjFunction* function, int argCount)
 {
        if (argCount != function->arity)
        {
            runtimeError("Expected " + String(function->arity)
                         + " arguments but got " + String(argCount)
                         + ".");

            return false;
        }

        if (frameCount == FRAMES_MAX)
        {
            runtimeError("Stack overflow.");
            return false;
        }

        CallFrame* frame = &frames[frameCount++];
        frame->function = function;
        frame->ip = function->chunk.code;
        frame->slots = stackTop - argCount - 1;
        return true;
 }

 u32 Process::addConstant(Value value) 
 { 
    constants.push_back(value);
    return constants.getSize() - 1;
 }

 void Process::writeChunk(u8 instruction, int line) 
 {
    function->chunk.write(instruction, line);
 }

 void Process::runtimeError(const String& message)
 {
     ERROR("Runtime error: %s", message.c_str());

     for (int i = frameCount - 1; i >= 0; i--)
        {
            CallFrame* frame = &frames[i];
            ObjFunction* function = frame->function;
            size_t instruction = frame->ip - function->chunk.code - 1;
            ERROR("[line %d] in ", function->chunk.lines[instruction]);   
            ERROR("%s()", function->name);
            
        }

        resetStack();
}



/*

bool Process::run()
{
    if (frameCount == 0)
    {
        runtimeError("Empty frames.");
        status = STATUS_DEAD;
        return false;
    }
    
    CallFrame* frame = &frames[frameCount - 1];   
    
    // Execute apenas UMA instrução por chamada
    uint8_t instruction = READ_BYTE();
    switch (instruction)
    {
        // ... seus cases existentes ...
    }
    
    // Retorna true se ainda está vivo e pode executar mais
    return status == STATUS_RUNNING;
}

*/

bool Process::run()
{
    if (frameCount == 0)
    {
        runtimeError("Empty frames.");
        status = STATUS_DEAD;
        return false;
    }
    CallFrame* frame = &frames[frameCount - 1];   

    #define READ_BYTE() (*frame->ip++)
    #define READ_SHORT() (frame->ip += 2,(uint16_t)((frame->ip[-2] << 8) | frame->ip[-1]))
    #define READ_CONSTANT() (constants[READ_BYTE()])

    bool debug = false;
    for(;;)
    {
    
        if (debug)
        {
            printf("          \n");
            for (Value* slot = stack; slot < stackTop; slot++)
            {
                printf("|\t");
                PRINT_VALUE(*slot);
                printf("\n");
            }
            printf("\n");
            
        }
        uint8_t instruction  = READ_BYTE();
        switch (instruction)
        {
            case OP_CONSTANT:
            {
                Value value = READ_CONSTANT();
                push(value);
                break;
            }
            case OP_NIL:
            {
                push(NIL());
                break;
            }
            case OP_TRUE:
            {
                push(BOOLEAN(true));
                break;
            }
            case OP_FALSE:
            {
                push(BOOLEAN(false));
                break;
            }
            case OP_POP:
            {
                pop();
                break;
            }
            case OP_HALT:
            {
                status = STATUS_KILLED;
                return false;
            }
            case OP_RETURN:
            {
                Value result = pop();
                frameCount--;
                if (frameCount == 0)
                {
                    INFO("Process '%s' finished", name);
                    status = STATUS_DEAD;
                    return false;
                }
                INFO("Process '%s' function returned", name);
                stackTop = frame->slots;
                push(result);
                frame = &frames[frameCount - 1];
                
               break;
            }
            case OP_PRINT:
            {
                Value value = pop();
                PRINT_VALUE(value);
                printf("\n");
                break;
            }
            case OP_CALL:
            {
                
                ObjFunction* function = interpreter->find_function("add");
                if(function == nullptr)
                {
                    runtimeError("Undefined function 'add'.");
                    return false;
                }

                
                if (!call(function, 0))
                {
                    runtimeError("Stack overflow.");
                    return false;
                }
                break;
            }
            case OP_ADD:
            {
                
                if (peek(0).type == ValueType::NUMBER && peek(1).type == ValueType::NUMBER)
                {
                    Value b = pop();
                    Value a = pop();
                    push(NUMBER(a.number + b.number));
                }
                else if (peek(0).type == ValueType::STRING && peek(1).type == ValueType::STRING)
                {
                    Value b = pop();
                    Value a = pop();
                    const char* textA = a.string->data;
                    const char* textB = b.string->data;

                    int length = snprintf(nullptr, 0, "%s%s", textA, textB);
                    if (length > 255)
                    {
                        runtimeError("String too long.");
                        return false;
                    }
                    char text[256];
                    snprintf(text, length + 1, "%s%s", textA, textB);
                    text[length] = '\0';
                    push(STRING(text));
                } else if (peek(0).type == ValueType::STRING && peek(1).type == ValueType::NUMBER)
                {
                
                    Value b = pop();
                    pop();
                    const char* textA = b.string->data;
                    
                    char text[256];
                    int length = snprintf(text, sizeof(text), "%s%d", textA, (int)b.number);
                    
                    if (length < 256) 
                    {
                        push(STRING(text));
                    } else 
                    {
                        char* dynText = (char*)malloc(length + 1);
                        if (!dynText) 
                        {
                            runtimeError("Memory allocation failed.");
                            return false;
                        }
                        snprintf(dynText, length + 1, "%s%d", textA, (int)b.number);
                        push(STRING(dynText));
                        free(dynText);
                    }
                }

                else
                {
                    PRINT_VALUE(peek(0));
                    PRINT_VALUE(peek(1));
                    runtimeError("Operation 'add' not supported.");
                    return false;
                }
                break;
            }
            case OP_SUBTRACT:
            {
                if (peek(0).type == ValueType::NUMBER && peek(1).type == ValueType::NUMBER)
                {
                    Value b = pop();
                    Value a = pop();
                    push(NUMBER(a.number - b.number));
                }
                else
                {
                    runtimeError("Operation 'sub' not supported.");
                }
                break;
            }
            case OP_MULTIPLY:
            {
                if (peek(0).type == ValueType::NUMBER && peek(1).type == ValueType::NUMBER)
                {
                    Value b = pop();
                    Value a = pop();
                    push(NUMBER(a.number * b.number));
                }
                else
                {
                    runtimeError("Operation 'mul' not supported.");
                }
                break;
            }
            case OP_DIVIDE:
            {
                if (peek(0).type == ValueType::NUMBER && peek(1).type == ValueType::NUMBER)
                {
                    Value b = pop();
                    Value a = pop();
                    push(NUMBER(a.number / b.number));
                }
                else
                {
                    runtimeError("Operation 'div' not supported.");
                }
                break;
            }

            default:
            {
                runtimeError("Unimplemented opcode."+String(instruction));
                return false;
            }
        }

    }
 


    return true;
}
