//#include "TestString.hpp"
//#include "TestChunk.hpp"
//#include "TestStack.hpp"
//#include "TestVector.hpp"
//#include "TesteQueue.hpp"
//#include "TestRai.hpp"
//#include "TesteMap.hpp"

#include "Config.hpp"
#include "VM.hpp"
#include "Utils.hpp"
#include "Lexer.hpp"
#include "Parser.hpp"
extern GarbageCollector GC;



//#define DEBUG_MEMORY

#ifdef DEBUG_MEMORY
static int allocation_count = 0;
static int deallocation_count = 0;

void* operator new(size_t size) {
    allocation_count++;
    return malloc(size);
}


void* operator new[](size_t size) {
    allocation_count++;
    return malloc(size);
}

void operator delete(void* ptr) {
    (void)ptr;
    deallocation_count++;
    free(ptr);
}

void operator delete[](void* ptr) {
    (void)ptr;
    deallocation_count++;
    free(ptr);
}

void operator delete(void*, long unsigned int) {}
void operator delete[](void*, long unsigned int) {}

void checkMemoryLeaks() 
{
    printf("=== MEMORY LEAK CHECK ===\n");
    printf("Allocations: %d\n", allocation_count);
    printf("Deallocations: %d\n", deallocation_count);
    if (allocation_count != deallocation_count) 
    {
        printf("MEMORY LEAK DETECTED!\n");
    } else 
    {
        printf("No memory leaks detected.\n");
    }

   
}
#endif

 
int main()
{

  // ChunkTester tester;
  //  tester.runAllTests();

//   StackTester tester;
//     tester.runAllTests();
 
//  SmartPointerTester tester;
//     tester.runAllTests();

    // QueueTester tester;
    //  tester.runAllTests();

//  VectorTester tester;
//     tester.runAllTests();

    // UnorderedMapTester tester;
    // tester.runAllTests();

    // UnorderedMapLookupTester tester2;
    // tester2.runAllLookupTests();

   // STRING("Hello, World!");

//    INTEGER(42);
//    NUMBER(3.14);
//    BOOLEAN(true);
//    NIL();

    
//    STRING("Hello, World!");
//       STRING("Hello, World!");   STRING("Hello, World!");   STRING("Hello, World!");   STRING("Hello, World!");   STRING("Hello, World!");   STRING("Hello, World!");


//     INFO("Objects before collection: %d", GC.countObjects());
//     GC.collect();
//     INFO("Objects after collection: %d", GC.countObjects());

    
//     Lexer lexer;
//     if (lexer.LoadFromFile("/home/djoker/code/cpp/bugame/div/bin/main.bu"))
//     {
//       lexer.print();
 
//     }
    
// Process process;
// process.writeChunk(OP_CONSTANT, 0);
// u32 index = process.addConstant(NUMBER(42));
// process.writeChunk(index, 0);
// process.writeChunk(OP_PRINT, 0);
// process.writeChunk(OP_RETURN, 0);

// process.call(process.function, 0);

// process.run();

   Interpreter vm;

  Process *process = vm.add_process("main",10);
  
  process->writeChunk(OP_CALL, 0);
  process->writeChunk(OP_CONSTANT, 0);
  u32 index = process->addConstant(NUMBER(0));
  process->writeChunk(index, 0);
  process->writeChunk(OP_PRINT, 0);
  process->writeChunk(OP_RETURN, 0);
  process->call(process->function, 0);
  
  
  ObjFunction* function = vm.add_function("add");
  
  function->chunk.write(OP_CONSTANT, 0);
  index = process->addConstant(NUMBER(2));
  function->chunk.write(index, 0);
  
  function->chunk.write(OP_CONSTANT, 0);
  index =  process->addConstant(NUMBER(2));
  function->chunk.write(index, 0);
  
  function->chunk.write(OP_ADD, 0);
  function->chunk.write(OP_PRINT, 0);
  function->chunk.write(OP_RETURN, 0);
  //process->call(function, 0);
  
  

//   process = vm.add_process("main2",100);
//   process->writeChunk(OP_CONSTANT, 0);
//   index = process->addConstant(STRING("Hello, World!"));
//   process->writeChunk(index, 0);
//   process->writeChunk(OP_PRINT, 0);
//   process->writeChunk(OP_RETURN, 0);
//   process->call(process->function, 0);

 
//    process = vm.add_process("add",10);
//    process->writeChunk(OP_CONSTANT, 0);
//    index = process->addConstant(NUMBER(2));
//    process->writeChunk(index, 0);

//    process->writeChunk(OP_CONSTANT, 0);
//    index = process->addConstant(STRING("Hello, World!"));

//    process->writeChunk(index, 0);
//    process->writeChunk(OP_ADD, 0);
//    process->writeChunk(OP_PRINT, 0);
//   process->writeChunk(OP_RETURN, 0);
//   process->call(process->function, 0);

 

  vm.run();
  vm.clear();

     INFO("Objects before collection: %d", GC.countObjects());
     GC.collect();
     INFO("Objects after collection: %d", GC.countObjects());


#ifdef DEBUG_MEMORY
    checkMemoryLeaks();
    #endif
   
    return 0;
}