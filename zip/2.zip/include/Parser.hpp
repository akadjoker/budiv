#pragma once

 
#include "Utils.hpp"
#include "Lexer.hpp"
#include "Raii.hpp"
 

class Parser;
class Interpreter;
class Process;
class ObjFunction;
class Value;

enum  Precedence {
    NONE = 0,
    ASSIGNMENT = 1,    // =, +=, -=
    OR = 2,           // OR
    AND = 3,          // AND
    BIT_OR = 4,       // |
    BIT_XOR = 5,      // ^^
    BIT_AND = 6,      // &
    EQUALITY = 7,     // ==, !=
    COMPARISON = 8,   // <, >, <=, >=
    SHIFT = 9,        // <<, >>
    TERM = 10,        // +, -
    FACTOR = 11,      // *, /, %
    POWER = 12,       // ^
    UNARY = 13,       // !, -, NOT, ~
    CALL = 14,        // . ()
    PRIMARY = 15,
    NOT = 16
};







typedef void (Parser::*PrefixFn)(bool canAssign);
typedef void (Parser::*InfixFn)( bool canAssign);


struct  ParseRule
{
  PrefixFn prefix;
  InfixFn infix;
  Precedence precedence;

  ParseRule() : prefix(nullptr), infix(nullptr), precedence(Precedence::NONE) {}
  
  ParseRule(PrefixFn p, InfixFn i, Precedence prec) 
      : prefix(p), infix(i), precedence(prec) {}

    
  ParseRule& operator=(const ParseRule& other) 
    {
        prefix = other.prefix;
        infix = other.infix;
        precedence = other.precedence;
        return *this;
    }

    
} ;


// // ParseRule class
// class ParseRule 
// {
// public:
//     PrefixFn prefix;
//     InfixFn infix;
//     Precedence precedence;
    
//     ParseRule() : prefix(nullptr), infix(nullptr), precedence(Precedence::NONE) {}
    
//     ParseRule(PrefixFn p, InfixFn i, Precedence prec) 
//         : prefix(p), infix(i), precedence(prec) {}
// };


class Parser 
{
private:
    Lexer *lexer;
    Token current;
    Token previous;
    bool had_error;
    bool panic_mode;
    int index;
   // UnorderedMap<TokenType, ParseRule> rules;
    Interpreter* vm;
    ParseRule rules[256];
    Process* current_process;
    ObjFunction* current_function;

    void parsePrecedence(Precedence precedence);

    ParseRule *getRule(TokenType type);
 

    //ParseRule rules[256];
    void initRules() ;
    void synchronize();
    void errorAtCurrent(const String& message);
    void error(const String& message);
    void errorAt(const Token& token, const String& message);
    void consume(TokenType type, const String& message);
    bool match(TokenType type);
    bool check(TokenType type);
    void advance();


        void expression(bool canAssign = false);
        void equality(bool canAssign = false);
        void comparison(bool canAssign = false);
        void grouping(bool canAssign = false);
        void term(bool canAssign = false);
        void factor(bool canAssign = false);
        void unary(bool canAssign = false);
        void power(bool canAssign = false);
        void call(bool canAssign = false);
        void primary(bool canAssign = false);
        void number(bool canAssign = false);
        void string(bool canAssign = false);
        void binary(bool canAssign = false);
        void block();
        
        void declaration();
        void statement();

        void printStatement();
        void varDeclaration();
        void expressionStatement();

        void emitConstant(Value value);
        void emitByte(u8 byte);
        void emitBytes(u8 byte1, u8 byte2);
        void endProcess();
 
        friend class Interpreter;   

public:
 
    Parser(Interpreter* vm);
    ~Parser();




    bool compile();
};