#include "Parser.hpp"
#include "VM.hpp"
#include "Token.hpp"
#include "Lexer.hpp"
#include <string>


typedef void (*ParseFn)(bool);


void Parser::parsePrecedence(Precedence precedence)
{
    advance();
    INFO("precedence: %d token: %d (%s)", precedence,
         static_cast<u32>(current.type),
         tknString(current.type).c_str()); // Adicione esta função helper

    ParseRule* prefixRule = getRule(previous.type);
    if (prefixRule->prefix == NULL)
    {
        error("Expect expression");
        return;
    }

    bool canAssign = precedence <= ASSIGNMENT;
    INFO("Call prefix for token: %s", tknString(previous.type).c_str());
    (this->*(prefixRule->prefix))(canAssign);

    while (precedence <= getRule(current.type)->precedence)
    {
        advance();
        ParseRule* infixRule = getRule(previous.type);
        if (infixRule->infix == NULL) break;

        INFO("Call infix for token: %s", tknString(previous.type).c_str());
        (this->*(infixRule->infix))(canAssign);
    }
}

ParseRule* Parser::getRule(TokenType type)
{
    u32 index = static_cast<u32>(type);
    return &rules[index];
}


void Parser::initRules()
{


    rules[static_cast<u32>(TokenType::LEFT_PAREN)] = { &Parser::grouping, NULL,
                                                       Precedence::NONE };
    rules[static_cast<u32>(TokenType::RIGHT_PAREN)] = { NULL, NULL,
                                                        Precedence::NONE };
    rules[static_cast<u32>(TokenType::LEFT_BRACE)] = { NULL, NULL,
                                                       Precedence::NONE };
    rules[static_cast<u32>(TokenType::RIGHT_BRACE)] = { NULL, NULL,
                                                        Precedence::NONE };
    rules[static_cast<u32>(TokenType::COMMA)] = { NULL, NULL,
                                                  Precedence::NONE };
    rules[static_cast<u32>(TokenType::DOT)] = { NULL, NULL, Precedence::NONE };
    rules[static_cast<u32>(TokenType::MINUS)] = { &Parser::unary,
                                                  &Parser::binary,
                                                  Precedence::TERM };
    rules[static_cast<u32>(TokenType::PLUS)] = { NULL, &Parser::binary,
                                                 Precedence::TERM };
    rules[static_cast<u32>(TokenType::SEMICOLON)] = { NULL, NULL,
                                                      Precedence::NONE };
    rules[static_cast<u32>(TokenType::SLASH)] = { NULL, &Parser::binary,
                                                  Precedence::FACTOR };
    rules[static_cast<u32>(TokenType::STAR)] = { NULL, &Parser::binary,
                                                 Precedence::FACTOR };
    rules[static_cast<u32>(TokenType::BANG)] = { NULL, NULL, Precedence::NONE };
    rules[static_cast<u32>(TokenType::BANG_EQUAL)] = { NULL, &Parser::binary,
                                                       Precedence::EQUALITY };
    rules[static_cast<u32>(TokenType::EQUAL)] = { NULL, NULL,
                                                  Precedence::NONE };
    rules[static_cast<u32>(TokenType::EQUAL_EQUAL)] = { NULL, &Parser::binary,
                                                        Precedence::EQUALITY };
    rules[static_cast<u32>(TokenType::GREATER)] = { NULL, &Parser::binary,
                                                    Precedence::COMPARISON };
    rules[static_cast<u32>(TokenType::GREATER_EQUAL)] = {
        NULL, &Parser::binary, Precedence::COMPARISON
    };
    rules[static_cast<u32>(TokenType::LESS)] = { NULL, &Parser::binary,
                                                 Precedence::COMPARISON };
    rules[static_cast<u32>(TokenType::LESS_EQUAL)] = { NULL, &Parser::binary,
                                                       Precedence::COMPARISON };
    rules[static_cast<u32>(TokenType::BANG)] = { &Parser::unary, NULL,
                                                 Precedence::NONE };
    // rules[static_cast<u32>(TokenType::IDENTIFIER)] = {&Parser::variable,
    // NULL, Precedence::NONE};
    rules[static_cast<u32>(TokenType::STRING)] = { &Parser::string, NULL,
                                                   Precedence::NONE };
    rules[static_cast<u32>(TokenType::NUMBER)] = { &Parser::number, NULL,
                                                   Precedence::NONE };
    rules[static_cast<u32>(TokenType::AND)] = { NULL, NULL, Precedence::NONE };
    rules[static_cast<u32>(TokenType::CLASS)] = { NULL, NULL,
                                                  Precedence::NONE };
    rules[static_cast<u32>(TokenType::ELSE)] = { NULL, NULL, Precedence::NONE };
    rules[static_cast<u32>(TokenType::FALSE)] = { NULL, NULL,
                                                  Precedence::NONE };
    rules[static_cast<u32>(TokenType::FOR)] = { NULL, NULL, Precedence::NONE };
    rules[static_cast<u32>(TokenType::FUNCTION)] = { NULL, NULL,
                                                     Precedence::NONE };
    rules[static_cast<u32>(TokenType::IF)] = { NULL, NULL, Precedence::NONE };
    rules[static_cast<u32>(TokenType::NIL)] = { NULL, NULL, Precedence::NONE };
    rules[static_cast<u32>(TokenType::OR)] = { NULL, NULL, Precedence::NONE };
    rules[static_cast<u32>(TokenType::PRINT)] = { NULL, NULL,
                                                  Precedence::NONE };
    rules[static_cast<u32>(TokenType::RETURN)] = { NULL, NULL,
                                                   Precedence::NONE };
    //  rules[static_cast<u32>(TokenType::SUPER)] = {NULL, NULL,
    //  Precedence::NONE};
    rules[static_cast<u32>(TokenType::THIS)] = { NULL, NULL, Precedence::NONE };
    rules[static_cast<u32>(TokenType::TRUE)] = { NULL, NULL, Precedence::NONE };
    rules[static_cast<u32>(TokenType::VAR)] = { NULL, NULL, Precedence::NONE };
    rules[static_cast<u32>(TokenType::WHILE)] = { NULL, NULL,
                                                  Precedence::NONE };

}

void Parser::errorAtCurrent(const String& message)
{
    errorAt(current, message);
}

void Parser::error(const String& message) { errorAt(previous, message); }

void Parser::errorAt(const Token& token, const String& message)
{
    if (panic_mode) return;
    panic_mode = true;
    if (token.type == TokenType::END_OF_FILE)
    {
        ERROR("[line %d] Error (%s) at end", token.line, message.c_str());
    }
    else
    {
        ERROR("[line %d] Error '%s' at  %s ", token.line, token.lexeme.c_str(), message.c_str());
    }

    had_error = true;
}

void Parser::consume(TokenType type, const String& message)
{
    if (current.type == type)
    {
        advance();
        return;
    }
    errorAtCurrent(message);
}

bool Parser::match(TokenType type)
{
    if (!check(type)) return false;
    advance();
    return true;
}

bool Parser::check(TokenType type) { return current.type == type; }


void Parser::emitConstant(Value value)
{
    u32 index = current_process->addConstant(std::move(value));
    emitBytes(OP_CONSTANT, index);
}

void Parser::emitByte(u8 byte)
{
    current_function->chunk.write(byte, current.line);
}

void Parser::emitBytes(u8 byte1, u8 byte2)
{
    emitByte(byte1);
    emitByte(byte2);
}

void Parser::endProcess()
{
    current_process->writeChunk(OP_HALT, 0);
    current_process->call(current_function, 0);
}

void Parser::synchronize()
{
    panic_mode = false;
    while (current.type != TokenType::END_OF_FILE)
    {
        if (previous.type == TokenType::SEMICOLON) return;
        switch (current.type)
        {
            case TokenType::CLASS:
            case TokenType::FUNCTION:
            case TokenType::VAR:
            case TokenType::FOR:
            case TokenType::IF:
            case TokenType::WHILE:
            case TokenType::PRINT:
            case TokenType::RETURN: return;
            default: break;
        }
        advance();
    }
}


Parser::Parser(Interpreter* vm)
{
    initRules();
    this->vm = vm;
    had_error = false;
    panic_mode = false;
    lexer = new Lexer();
}

Parser::~Parser() { delete lexer; }


void Parser::advance()
{
    previous = current;
    for (;;)
    {
        current = lexer->scanToken();
        if (current.type != TokenType::ERROR) break;
        errorAtCurrent(current.lexeme);
    }
}


bool Parser::compile()
{
    current_process = vm->add_process("_main_", 0);
    current_function = current_process->function;

    INFO("Parsing started");


    advance();

    while (!match(TokenType::END_OF_FILE))
    {

        declaration();
    }


    endProcess();

    INFO("Parsing done");

    return !had_error;
}


void Parser::declaration()
{
    if (match(TokenType::VAR))
    {
        varDeclaration();
    }
    else
    {
        statement();
    }

    if (panic_mode) synchronize();
}

void Parser::statement()
{
      INFO("TokenType::PRINT value: %d", static_cast<int>(TokenType::PRINT));
    
    if (match(TokenType::PRINT))
    {
        INFO("Successfully matched PRINT token");
        printStatement();
    }
    else 
    {
        INFO("Failed to match PRINT, going to expression statement");
        expressionStatement();
    }
}

void Parser::printStatement()
{
    INFO("print statement");
    consume(TokenType::LEFT_PAREN, "Expect '(' after 'print'.");
    expression();
    consume(TokenType::RIGHT_PAREN, "Expect ')' after expression.");
    consume(TokenType::SEMICOLON, "Expect ';' after value.");
    emitByte(OP_PRINT);
}

void Parser::varDeclaration()
{

    INFO("var declaration");

    consume(TokenType::IDENTIFIER, "Expect variable name.");

    String name = previous.lexeme;

    INFO("declaring variable: %s", name.c_str());

    if (match(TokenType::EQUAL))
    {
        expression();
    }
    else
    {

        emitByte(OP_NIL);
    }

    consume(TokenType::SEMICOLON, "Expect ';' after variable declaration.");


    //   Value value = NIL();
    //   emitConstant(std::move(value));
    //   consume(TokenType::EQUAL, "Expect '=' after variable name.");
    //   expression();
    //   consume(TokenType::SEMICOLON, "Expect ';' after variable
    //   declaration.");


    //       uint8_t global = parseVariable("Expect variable name.");

    //   if (match(TOKEN_EQUAL)) {
    //     expression();
    //   } else {
    //     emitByte(OP_NIL);
    //   }
    //   consume(TOKEN_SEMICOLON,
    //           "Expect ';' after variable declaration.");

    //   defineVariable(global);
}

void Parser::expressionStatement()
{
    INFO("expression statement");
    expression();
    consume(TokenType::SEMICOLON, "Expect ';' after expression.");
    emitByte(OP_POP);
}

void Parser::expression(bool canAssign)
{
    INFO("expression");
    parsePrecedence(ASSIGNMENT);
}

void Parser::grouping(bool canAssign)
{
    INFO("grouping");
    expression();
    consume(TokenType::RIGHT_PAREN, "Expect ')' after expression.");
}


void Parser::number(bool canAssign)
{
    Value value = NUMBER(std::stod(previous.lexeme.c_str()));

    emitConstant(std::move((value)));
}

void Parser::string(bool canAssign)
{

    Value value = STRING(previous.lexeme.c_str());
    emitConstant(std::move(value));
}

void Parser::binary(bool canAssign)
{

    INFO("binary");
    TokenType operatorType = previous.type;

    ParseRule* rule = getRule(operatorType);
    parsePrecedence((Precedence)(rule->precedence + 1));

    switch (operatorType)
    {
        case TokenType::PLUS: emitByte(OP_ADD); break;
        case TokenType::MINUS: emitByte(OP_SUBTRACT); break;
        case TokenType::STAR: emitByte(OP_MULTIPLY); break;
        case TokenType::SLASH: emitByte(OP_DIVIDE); break;
        case TokenType::MOD: emitByte(OP_MODULO); break;
        case TokenType::POWER: emitByte(OP_POWER); break;
        case TokenType::EQUAL_EQUAL: emitByte(OP_EQUAL); break;
        case TokenType::BANG_EQUAL: emitByte(OP_NOT_EQUAL); break;
        case TokenType::LESS: emitByte(OP_LESS); break;
        case TokenType::GREATER: emitByte(OP_GREATER); break;
        case TokenType::LESS_EQUAL: emitByte(OP_LESS_EQUAL); break;
        case TokenType::GREATER_EQUAL: emitByte(OP_GREATER_EQUAL); break;
        default: return; // Unreachable.
    }
}
void Parser::unary(bool canAssign)
{
    INFO("unary");

    TokenType operatorType = previous.type;

    // Compile the operand.
    parsePrecedence(UNARY);

    // Emit the operator instruction.
    switch (operatorType)
    {
        case TokenType::MINUS: emitByte(OP_NEGATE); break;
        case TokenType::BANG: emitByte(OP_NOT); break;
        default: return; // Unreachable.
    }
}
