//#include "TestString.hpp"
//#include "TestChunk.hpp"
//#include "TestStack.hpp"
//#include "TestVector.hpp"
//#include "TesteQueue.hpp"
//#include "TestRai.hpp"
//#include "TesteMap.hpp"

#include "Config.hpp"
#include "VM.hpp"
#include "Utils.hpp"
#include "Lexer.hpp"
#include "Parser.hpp"
extern GarbageCollector GC;



//#define DEBUG_MEMORY

#ifdef DEBUG_MEMORY
static int allocation_count = 0;
static int deallocation_count = 0;

void* operator new(size_t size) {
    allocation_count++;
    return malloc(size);
}


void* operator new[](size_t size) {
    allocation_count++;
    return malloc(size);
}

void operator delete(void* ptr) {
    (void)ptr;
    deallocation_count++;
    free(ptr);
}

void operator delete[](void* ptr) {
    (void)ptr;
    deallocation_count++;
    free(ptr);
}

void operator delete(void*, long unsigned int) {}
void operator delete[](void*, long unsigned int) {}

void checkMemoryLeaks() 
{
    printf("=== MEMORY LEAK CHECK ===\n");
    printf("Allocations: %d\n", allocation_count);
    printf("Deallocations: %d\n", deallocation_count);
    if (allocation_count != deallocation_count) 
    {
        printf("MEMORY LEAK DETECTED!\n");
    } else 
    {
        printf("No memory leaks detected.\n");
    }

   
}
#endif

 
int main()
{

 

   Interpreter vm;


   if (vm.compile_file("main.bu"))
   {
       vm.disassemble();
       // vm.run();
   }
 
  vm.clear();

     INFO("Objects before collection: %d", GC.countObjects());
     GC.collect();
     INFO("Objects after collection: %d", GC.countObjects());


#ifdef DEBUG_MEMORY
    checkMemoryLeaks();
    #endif
   
    return 0;
}